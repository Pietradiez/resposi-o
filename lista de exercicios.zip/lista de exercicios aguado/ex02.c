#include<stdio.h>

int main() {
float valorFatura, cashback;

printf("Informe o valor da fatura: R$ ");
scanf("%f", &valorFatura);

if (valorFatura <= 1000) {
cashback = 0.0;
} else if (valorFatura <= 4000) {
cashback = valorFatura * 0.01;
} else if (valorFatura <= 8000) {
cashback = valorFatura * 0.02;
} else {
cashback = valorFatura * 0.05;
}

printf("O valor do cashback e: R$ %.2f\n", cashback);

return 0;
}
