valor = float(input("Digite o valor da sua compra: R$"))
socio = input("Voce e socio do clibe Delta? sim/nao:")
idade = int(input("Digite sua idade:"))
aniversario = input("Esta fazendo aniversario hoje? sim/nao:")

desconto = 0

if valor > 100:
    if socio =="sim" or idade > 60:
        desconto += 10
    if socio =="sim" and aniversario == "sim":
        desconto += 5

    valor_final = valor - desconto
    print(f"Valor final da compra: R$ {valor_final:.2f}")